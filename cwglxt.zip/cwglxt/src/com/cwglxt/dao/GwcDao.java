package com.cwglxt.dao;

import com.cwglxt.entity.Gwc;
import com.cwglxt.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GwcDao {
    Connection connection = null;
    PreparedStatement ps = null;
    ResultSet rlt = null;

    public int addGwc(Gwc gwc){
        int flag = 0;
        String sqlString = "insert into gwc(name,jg,photo) value (?,?,?);";
        connection = DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);

            ps.setString(1, gwc.getName());
            ps.setString(2, gwc.getJg());
            ps.setString(3,gwc.getPhoto());

            flag = ps.executeUpdate();
            connection.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public List<Gwc> findAllGwc(){
        List<Gwc>gwcList = new ArrayList<>();
        String sqlString = "select * from gwc";
        connection = DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);
            rlt = ps.executeQuery();

            while (rlt.next()){
                Gwc gwc = new Gwc();
                gwc.setId(rlt.getInt(1));
                gwc.setName(rlt.getString(2));
                gwc.setJg(rlt.getString(3));
                gwc.setPhoto(rlt.getString(4));

                gwcList.add(gwc);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return gwcList;
    }

    public int deleteGwc(int id){
        int count = 0;
        String sqlString = "delete from gwc where id=?;";
        connection = DBUtil.getConnection();
        try {
            ps = connection.prepareStatement(sqlString);
            ps.setInt(1,id);
            count = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return count;
    }
}
