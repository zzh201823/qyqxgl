package com.cwglxt.dao;

import com.cwglxt.entity.Food;
import com.cwglxt.entity.Food;
import com.cwglxt.entity.Food;
import com.cwglxt.entity.Pet;
import com.cwglxt.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FoodDao {
    Connection connection = null;
    PreparedStatement ps = null;
    ResultSet rlt = null;

    public int addFood(Food food){
        int flag = 0;
        String sqlString = "insert into food(name,zt,stock,jg) value (?,?,?,?);";
        connection = DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);

            ps.setString(1, food.getName());
            ps.setString(2, food.getZt());
            ps.setString(3, food.getStock());
            ps.setString(4, food.getJg());

            flag = ps.executeUpdate();
            connection.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public List<Food> findAllFood(){
        List<Food>foodList = new ArrayList<>();
        String sqlString = "select * from food";
        connection = DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);
            rlt = ps.executeQuery();

            while (rlt.next()){
                Food food = new Food();
                food.setId(rlt.getInt(1));
                food.setName(rlt.getString(2));
                food.setZt(rlt.getString(3));
                food.setStock(rlt.getString(4));
                food.setJg(rlt.getString(5));
                food.setPhoto(rlt.getString(6));
                foodList.add(food);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return foodList;
    }

    public int updateFood(Food food){
        int flags = 0;
        String sqlString = "Update food set name=?,zt=?,stock=?,jg=? where id=?";
        connection = DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);
            ps.setString(1, food.getName());
            ps.setString(2, food.getZt());
            ps.setString(3, food.getStock());
            ps.setString(4,food.getJg());
            ps.setInt(5, food.getId());

            flags = ps.executeUpdate();
            connection.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flags;
    }

    public int deleteFood(int id){
        int count = 0;
        String sqlString = "delete from food where id=?;";
        connection = DBUtil.getConnection();
        try {
            ps = connection.prepareStatement(sqlString);
            ps.setInt(1,id);
            count = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return count;
    }

    public List<Food> findFood(String name){
        List<Food> foodList=new ArrayList<>();

        String sqlString="select * from food where name like ? ";
        connection=DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);
            //给占位符赋值
            ps.setString(1,name);
            rlt = ps.executeQuery();
            //获取结果集对象中的学生信息
            while (rlt.next()){
                Food food = new Food();
                food.setId(rlt.getInt(1));
                food.setName(rlt.getString(2));
                food.setZt(rlt.getString(3));
                food.setStock(rlt.getString(4));
                food.setJg(rlt.getString(5));
                food.setPhoto(rlt.getString(6));
                foodList.add(food);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return foodList;
    }
}
