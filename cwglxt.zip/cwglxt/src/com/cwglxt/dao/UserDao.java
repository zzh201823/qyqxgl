package com.cwglxt.dao;

import com.cwglxt.entity.User;
import com.cwglxt.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
    Connection connection=null;
    PreparedStatement ps=null;
    ResultSet rs=null;

    public int addUser(User user){
        int flag = 0;
        String sqlString = "insert into user(username,password) values(?,?);";
        connection = DBUtil.getConnection();
        try {
            ps = connection.prepareStatement(sqlString);
            ps.setString(1,user.getUsername());
            ps.setString(2, user.getPassword());

            flag = ps.executeUpdate();
            connection.close();
            ps.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return flag;
    }

    public List<User> findAllUser(){
        List<User> userList = new ArrayList<>();
        String sqlString = "select * from user ";
        connection = DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);
            rs = ps.executeQuery();
            while (rs.next()){
                User user = new User();
                user.setId(rs.getInt(1));
                user.setUsername(rs.getString(2));
                user.setPassword(rs.getString(3));

                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userList;
    }

    public List<User> FindUser(String username, String password){
        List<User> userList=new ArrayList<User>();
        ResultSet rs=null;
        String sqlString="Select username,password,power From user Where username=? and password=?;";
        connection= DBUtil.getConnection();
        try {
            ps = connection.prepareStatement(sqlString);
            ps.setString(1,username);
            ps.setString(2,password);
            rs=ps.executeQuery();
            while (rs.next()){
                User user=new User();
                user.setUsername(rs.getString(1));
                user.setPassword(rs.getString(2));
                user.setPower(rs.getString(3));
                userList.add(user);
            }
        }catch (SQLException throwables){
            throwables.printStackTrace();
        }
        return userList;
    }

    public  int UpdatePassword(User user,String password){
        int flag=0;
        String sqlString="update user set password=? where username=? and password=?";
        connection= DBUtil.getConnection();
        try {
            //给占位符？赋值
            ps=connection.prepareStatement(sqlString);
            ps.setString(1, password);
            ps.setString(2, user.getUsername());
            ps.setString(3, user.getPassword());
            //执行sql语句
            flag=ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public  int UpdateUser(User user){
        int flag=0;
        String sqlString="update user set username=?,password=? where id=?";
        connection= DBUtil.getConnection();
        try {
            //给占位符？赋值
            ps=connection.prepareStatement(sqlString);
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setInt(3, user.getId());
            //执行sql语句
            flag=ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public int deleteUser(Integer id){
        int count=0;
        try {
            String del = "delete from user where id=?";
            connection=DBUtil.getConnection();
            ps = connection.prepareStatement(del);
            ps.setInt(1,id);
            count = ps.executeUpdate();
        } catch (SQLException throwables){
            throwables.printStackTrace();
        }
        return count;
    }
}
