package com.cwglxt.dao;

import com.cwglxt.entity.Food;
import com.cwglxt.entity.Jewelry;
import com.cwglxt.entity.Pet;
import com.cwglxt.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JewelryDao {

    Connection connection = null;
    PreparedStatement ps = null;
    ResultSet rlt = null;

    public int addJewelry(Jewelry jewelry){
        int flag = 0;
        String sqlString = "insert into jewelry(name,zt,stock,jg) value (?,?,?,?);";
        connection = DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);

            ps.setString(1, jewelry.getName());
            ps.setString(2, jewelry.getZt());
            ps.setString(3, jewelry.getStock());
            ps.setString(4, jewelry.getJg());

            flag = ps.executeUpdate();
            connection.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public List<Jewelry> findAllJewelry(){
        List<Jewelry>jewelryList = new ArrayList<>();
        String sqlString = "select * from jewelry";
        connection = DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);
            rlt = ps.executeQuery();

            while (rlt.next()){
                Jewelry jewelry = new Jewelry();
                jewelry.setId(rlt.getInt(1));
                jewelry.setName(rlt.getString(2));
                jewelry.setZt(rlt.getString(3));
                jewelry.setStock(rlt.getString(4));
                jewelry.setJg(rlt.getString(5));
                jewelry.setPhoto(rlt.getString(6));
                jewelryList.add(jewelry);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jewelryList;
    }

    public int updateJewelry(Jewelry jewelry){
        int flags = 0;
        String sqlString = "Update jewelry set name=?,zt=?,stock=?,jg=? where id=?";
        connection = DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);
            ps.setString(1, jewelry.getName());
            ps.setString(2, jewelry.getZt());
            ps.setString(3, jewelry.getStock());
            ps.setString(4,jewelry.getJg());
            ps.setInt(5, jewelry.getId());

            flags = ps.executeUpdate();
            connection.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flags;
    }

    public int deleteJewelry(int id){
        int count = 0;
        String sqlString = "delete from jewelry where id=?;";
        connection = DBUtil.getConnection();
        try {
            ps = connection.prepareStatement(sqlString);
            ps.setInt(1,id);
            count = ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return count;
    }

    public List<Jewelry> findJewelry(String name){
        List<Jewelry> jewelryList=new ArrayList<>();

        String sqlString="select * from jewelry where name like ? ";
        connection=DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);
            //给占位符赋值
            ps.setString(1,name);
            rlt = ps.executeQuery();
            //获取结果集对象中的学生信息
            while (rlt.next()){
                Jewelry jewelry = new Jewelry();
                jewelry.setId(rlt.getInt(1));
                jewelry.setName(rlt.getString(2));
                jewelry.setZt(rlt.getString(3));
                jewelry.setStock(rlt.getString(4));
                jewelry.setJg(rlt.getString(5));
                jewelry.setPhoto(rlt.getString(6));
                jewelryList.add(jewelry);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return jewelryList;
    }
}
