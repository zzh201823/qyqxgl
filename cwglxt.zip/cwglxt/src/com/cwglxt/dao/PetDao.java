package com.cwglxt.dao;

import com.cwglxt.entity.Pet;
import com.cwglxt.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PetDao {
    Connection connection = null;
    PreparedStatement ps = null;
    ResultSet rlt = null;

    public int addPet(Pet pet){
        int flag = 0;
        String sqlString = "insert into pet(race,jewelry,food,zt,guas,jg) values(?,?,?,?,?,?);";
        connection = DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);
            ps.setString(1,pet.getRace());
            ps.setString(2,pet.getJewelry());
            ps.setString(3,pet.getFood());
            ps.setString(4,pet.getZt());
            ps.setString(5,pet.getGuas());
            ps.setString(6,pet.getJg());

            flag = ps.executeUpdate();
            connection.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public List<Pet>findAllPets(){
        List<Pet>petList = new ArrayList<>();
        String sqlString = "select * from pet";
        connection = DBUtil.getConnection();

        try {
            ps = connection.prepareStatement(sqlString);
            rlt = ps.executeQuery();
            while (rlt.next()){
                Pet pet = new Pet();
                pet.setId(rlt.getInt(1));
                pet.setRace(rlt.getString(2));
                pet.setJewelry(rlt.getString(3));
                pet.setFood(rlt.getString(4));
                pet.setZt(rlt.getString(5));
                pet.setGuas(rlt.getString(6));
                pet.setJg(rlt.getString(7));
                pet.setPhoto(rlt.getString(8));
                petList.add(pet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return petList;
    }

    public int updatePet(Pet pet){
        int flag = 0;
        String sqlString = "update pet set race=?,jewelry=?,food=?,zt=?,guas=?,jg=? where id=?;";
        connection = DBUtil.getConnection();
        try {
            ps = connection.prepareStatement(sqlString);
            ps.setString(1, pet.getRace());
            ps.setString(2, pet.getJewelry());
            ps.setString(3, pet.getFood());
            ps.setString(4, pet.getZt());
            ps.setString(5, pet.getGuas());
            ps.setString(6,pet.getJg());
            ps.setInt(7, pet.getId());

            flag = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public int deletePet(int id){
        int count = 0;
        String sqlString = "delete from pet where id=?;";
        connection = DBUtil.getConnection();
        try {
            ps = connection.prepareStatement(sqlString);
            ps.setInt(1,id);
            count = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return count;
    }

    public List<Pet> findPet(String race){
        List<Pet> petList=new ArrayList<>();

        String sqlString="select * from pet where race like ? ";
        connection=DBUtil.getConnection();
        try {
            ps = connection.prepareStatement(sqlString);
            //给占位符赋值
            ps.setString(1,race);
            rlt = ps.executeQuery();
            //获取结果集对象中的学生信息
            while (rlt.next()){
                Pet pet = new Pet();
                pet.setId(rlt.getInt(1));
                pet.setRace(rlt.getString(2));
                pet.setJewelry(rlt.getString(3));
                pet.setFood(rlt.getString(4));
                pet.setZt(rlt.getString(5));
                pet.setGuas(rlt.getString(6));
                pet.setJg(rlt.getString(7));
                pet.setPhoto(rlt.getString(8));
                petList.add(pet);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return petList;
    }
}
