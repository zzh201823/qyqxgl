package com.cwglxt.controller;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.UUID;

@WebServlet("/servletUploadPhoto")
public class ServletUploadPhoto extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        String root=request.getSession().getServletContext().getRealPath("upload");
        try {
//创建一个解析器工厂
            DiskFileItemFactory factory = new DiskFileItemFactory();
            // 文件上传解析器
            ServletFileUpload upload = new ServletFileUpload(factory);
            //解析请求，将表单中每个输入项封装成一个FileItem对象
            List<FileItem> list = upload.parseRequest(request);
            for(FileItem item : list) {
                if(item.isFormField() == false) {
                    //生成一个新的文件名，使用 UUID( 唯一识别的通用码 ), 保证文件名唯一
                    String filename= UUID.randomUUID().toString()+".jpg";
                    //保存图片到指定路径
                    File f = new File(root+"\\"+filename);
                    item.write(f);
                    out.print(filename);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        out.flush();
        out.close();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
