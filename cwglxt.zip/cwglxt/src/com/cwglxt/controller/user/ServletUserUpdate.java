package com.cwglxt.controller.user;

import com.cwglxt.dao.UserDao;
import com.cwglxt.entity.User;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/servletUserUpdate")
public class ServletUserUpdate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        //1.获取添加数据的参数
        User user = new User();
        user.setPassword(request.getParameter("password"));
        user.setUsername(request.getParameter("username"));
        user.setId(Integer.parseInt(request.getParameter("id")));
        //2.创建UserDao对象
        UserDao userDao = new UserDao();
        //调用方法

        int flag= userDao.UpdateUser(user);

        //判断是否添加成功
        if (flag>0){
            out.print("修改成功");
        }else {
            out.print("修改失败");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
