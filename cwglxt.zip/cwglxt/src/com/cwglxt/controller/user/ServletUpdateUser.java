package com.cwglxt.controller.user;

import com.cwglxt.dao.UserDao;
import com.cwglxt.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/servletUpdateUser")
public class ServletUpdateUser extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        //1.获取添加数据的参数
        User user = new User();
        user.setPassword(request.getParameter("password1"));
        user.setUsername(request.getParameter("username"));
        //2.创建UserDao对象
        UserDao userDao = new UserDao();
        //调用方法

        int flag= userDao.UpdatePassword(user,request.getParameter("password"));

        //判断是否添加成功
        if (flag>0){
            out.print("修改成功");
        }else {
            out.print("修改失败");
        }
    }
}
