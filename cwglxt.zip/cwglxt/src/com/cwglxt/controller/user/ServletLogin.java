package com.cwglxt.controller.user;

import com.cwglxt.dao.UserDao;
import com.cwglxt.entity.User;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/servletLogin")
public class ServletLogin extends HttpServlet {

    @Override
    protected void doGet ( HttpServletRequest request , HttpServletResponse response ) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();

        User user=new User();
        String username=request.getParameter("username");
        String password=request.getParameter("password");

        UserDao userDao=new UserDao();
        List<User> list=new ArrayList<User>();
        list=userDao.FindUser(username,password);

        System.out.println(list.size());
        if (list.size()>0){
            if (list.get(0).getPower().equals("0"))
                out.print("超级用户登录成功");
            else if(list.get(0).getPower().equals("1"))
                out.print("普通用户登录成功");
        }else{
            out.print("登录失败！！账号或密码错误");
        }
        out.flush();
        out.close();
    }

    @Override
    protected void doPost ( HttpServletRequest request , HttpServletResponse response ) throws ServletException, IOException {

    }
}
