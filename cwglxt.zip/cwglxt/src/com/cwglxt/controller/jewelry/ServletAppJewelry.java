package com.cwglxt.controller.jewelry;

import com.cwglxt.dao.JewelryDao;
import com.cwglxt.dao.PetDao;
import com.cwglxt.entity.Jewelry;
import com.cwglxt.entity.Pet;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/servletAppJewelry")
public class ServletAppJewelry extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //实现对数据表的添加功能
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        //1.获取添加数据的参数
        Jewelry jewelry = new Jewelry();
        jewelry.setName(request.getParameter("name"));
        jewelry.setZt(request.getParameter("zt"));
        jewelry.setStock(request.getParameter("stock"));
        jewelry.setJg(request.getParameter("jg"));
        //2.创建StudentDao对象
        JewelryDao jewelryDao = new JewelryDao();
        //调用方法
        int flag=jewelryDao.addJewelry(jewelry);
        //判断是否添加成功
        if (flag>0){
            out.print("添加成功");
        }else {
            out.print("添加失败");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
