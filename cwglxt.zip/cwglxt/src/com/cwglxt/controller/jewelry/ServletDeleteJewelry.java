package com.cwglxt.controller.jewelry;

import com.cwglxt.dao.JewelryDao;
import com.cwglxt.dao.PetDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/servletDeleteJewelry")
public class ServletDeleteJewelry extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        //1、获取添加数据的参数
        int id = Integer.valueOf(request.getParameter("id"));
        //2、创建studentdao对象
        JewelryDao jewelryDao = new JewelryDao();
        //3、调用修改方法
        int flag = jewelryDao.deleteJewelry(id);
        //4、判断是否添加成功
        if (flag>0){
            out.print("删除成功");
        }else {
            out.print("删除失败");
        }
    }
}
