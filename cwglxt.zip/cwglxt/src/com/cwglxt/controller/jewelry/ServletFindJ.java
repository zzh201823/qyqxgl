package com.cwglxt.controller.jewelry;

import com.cwglxt.dao.JewelryDao;
import com.cwglxt.entity.Jewelry;
import com.cwglxt.util.JsonTool;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/servletFindJ")
public class ServletFindJ extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        //1.获取安卓传递过来的查询数据
        String name= request.getParameter("name");

        List<Jewelry> jewelryList = new ArrayList<>();
        JewelryDao jewelryDao = new JewelryDao();
        jewelryList = jewelryDao.findJewelry(name);//调用按条件查询
        //转换jsonstring
        String jsonString = JsonTool.javaToJson(jewelryList);
        out.print(jsonString);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
