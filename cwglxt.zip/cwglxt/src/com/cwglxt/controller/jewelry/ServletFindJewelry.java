package com.cwglxt.controller.jewelry;

import com.cwglxt.dao.JewelryDao;
import com.cwglxt.dao.PetDao;
import com.cwglxt.entity.Jewelry;
import com.cwglxt.entity.Pet;
import com.cwglxt.util.JsonTool;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/servletFindJewelry")
public class ServletFindJewelry extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        //创建集合存放学生信息
        List<Jewelry> jewelryList = new ArrayList<>();
        JewelryDao jewelryDao = new JewelryDao();
        jewelryList = jewelryDao.findAllJewelry();
        String json = JsonTool.javaToJson(jewelryList);
        out.print(json);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
