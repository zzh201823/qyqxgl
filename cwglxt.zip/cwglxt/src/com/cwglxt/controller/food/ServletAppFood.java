package com.cwglxt.controller.food;

import com.cwglxt.dao.FoodDao;
import com.cwglxt.entity.Food;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/servletAppFood")
public class ServletAppFood extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //实现对数据表的添加功能
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        //1.获取添加数据的参数
        Food food = new Food();
        food.setName(request.getParameter("name"));
        food.setZt(request.getParameter("zt"));
        food.setStock(request.getParameter("stock"));
        food.setJg(request.getParameter("jg"));
        //2.创建StudentDao对象
        FoodDao foodDao = new FoodDao();
        //调用方法
        int flag=foodDao.addFood(food);
        //判断是否添加成功
        if (flag>0){
            out.print("添加成功");
        }else {
            out.print("添加失败");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
