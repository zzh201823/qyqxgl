package com.cwglxt.controller.food;

import com.cwglxt.dao.FoodDao;
import com.cwglxt.entity.Food;
import com.cwglxt.util.JsonTool;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/servletFindFood")
public class ServletFindFood extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        //创建集合存放学生信息
        List<Food> foodList = new ArrayList<>();
        FoodDao foodDao = new FoodDao();
        foodList = foodDao.findAllFood();
        String json = JsonTool.javaToJson(foodList);
        out.print(json);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
    }
}
