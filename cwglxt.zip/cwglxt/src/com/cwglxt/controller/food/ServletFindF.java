package com.cwglxt.controller.food;

import com.cwglxt.dao.FoodDao;
import com.cwglxt.entity.Food;
import com.cwglxt.util.JsonTool;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/servletFindF")
public class ServletFindF extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        //1.获取安卓传递过来的查询数据
        String name= request.getParameter("name");

        List<Food> foodList = new ArrayList<>();
        FoodDao foodDao = new FoodDao();
        foodList = foodDao.findFood(name);//调用按条件查询
        //转换jsonstring
        String jsonString = JsonTool.javaToJson(foodList);
        out.print(jsonString);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
