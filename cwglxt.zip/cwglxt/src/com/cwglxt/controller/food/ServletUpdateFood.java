package com.cwglxt.controller.food;

import com.cwglxt.dao.FoodDao;
import com.cwglxt.entity.Food;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/servletUpdateFood")
public class ServletUpdateFood extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        //1.获取添加数据的参数
        Food food = new Food();

        food.setName(request.getParameter("name"));
        food.setZt(request.getParameter("zt"));
        food.setStock(request.getParameter("stock"));
        food.setJg(request.getParameter("jg"));
        food.setId(Integer.parseInt(request.getParameter("id")));
        //2.创建PetDao对象
        FoodDao foodDao = new FoodDao();
        //调用方法
        int flags = foodDao.updateFood(food);
        //判断是否添加成功
        if (flags >0){
            out.print("修改成功");
        }else {
            out.print("修改失败");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
