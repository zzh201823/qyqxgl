package com.cwglxt.controller.gwc;

import com.cwglxt.dao.GwcDao;
import com.cwglxt.dao.PetDao;
import com.cwglxt.entity.Gwc;
import com.cwglxt.entity.Pet;
import com.cwglxt.util.JsonTool;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/servletGwcFind")
public class ServletGwcFind extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();

        List<Gwc> gwcList = new ArrayList<>();
        GwcDao gwcDao = new GwcDao();
        gwcList = gwcDao.findAllGwc();

        String json = JsonTool.javaToJson(gwcList);
        out.print(json);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
