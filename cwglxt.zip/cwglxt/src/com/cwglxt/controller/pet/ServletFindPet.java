package com.cwglxt.controller.pet;

import com.cwglxt.dao.PetDao;
import com.cwglxt.entity.Pet;
import com.cwglxt.util.JsonTool;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/servletFindPet")
public class ServletFindPet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        //创建集合存放学生信息
        List<Pet> petList = new ArrayList<>();
        PetDao petDao = new PetDao();
        petList = petDao.findAllPets();
        //将studentList对象转换成json数据
        String json = JsonTool.javaToJson(petList);
        out.print(json);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
