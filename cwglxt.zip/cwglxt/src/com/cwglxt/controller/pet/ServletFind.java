package com.cwglxt.controller.pet;

import com.cwglxt.dao.PetDao;
import com.cwglxt.entity.Pet;
import com.cwglxt.util.JsonTool;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/servletFind")
public class ServletFind extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        //1.获取安卓传递过来的查询数据
        String race= request.getParameter("race");

        List<Pet> petList = new ArrayList<>();
        PetDao petDao = new PetDao();
        petList = petDao.findPet(race);//调用按条件查询
        //转换jsonstring
        String jsonString = JsonTool.javaToJson(petList);
        out.print(jsonString);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
