package com.cwglxt.controller.pet;

import com.cwglxt.dao.PetDao;
import com.cwglxt.entity.Pet;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/servletAddPet")
public class ServletAddPet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //实现对数据表的添加功能
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        //1.获取添加数据的参数
        Pet pet = new Pet();
        pet.setRace(request.getParameter("race"));
        pet.setJewelry(request.getParameter("jewelry"));
        pet.setFood(request.getParameter("food"));
        pet.setZt(request.getParameter("zt"));
        pet.setGuas(request.getParameter("guas"));
        pet.setJg(request.getParameter("jg"));
        //2.创建StudentDao对象
        PetDao petDao = new PetDao();
        //调用方法
        int flag=petDao.addPet(pet);
        //判断是否添加成功
        if (flag>0){
            out.print("添加成功");
        }else {
            out.print("添加失败");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
