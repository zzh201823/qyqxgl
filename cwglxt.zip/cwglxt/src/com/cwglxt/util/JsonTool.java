package com.cwglxt.util;

import com.google.gson.Gson;

public class JsonTool {
    public static String javaToJson(Object value){
        Gson gson = new Gson();
        String jsonString =gson.toJson(value);
        return jsonString;
    }
}
