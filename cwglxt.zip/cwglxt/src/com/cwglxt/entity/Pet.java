package com.cwglxt.entity;

public class Pet {
    private int id;
    private String race;
    private String jewelry;
    private String food;
    private String zt;
    private String guas;
    private String jg;
    private String photo;

    public Pet() {
    }

    public Pet(int id, String race, String jewelry, String food, String zt, String guas, String jg, String photo) {
        this.id = id;
        this.race = race;
        this.jewelry = jewelry;
        this.food = food;
        this.zt = zt;
        this.guas = guas;
        this.jg = jg;
        this.photo = photo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    public String getJewelry() {
        return jewelry;
    }

    public void setJewelry(String jewelry) {
        this.jewelry = jewelry;
    }

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }

    public String getZt() {
        return zt;
    }

    public void setZt(String zt) {
        this.zt = zt;
    }

    public String getGuas() {
        return guas;
    }

    public void setGuas(String guas) {
        this.guas = guas;
    }

    public String getJg() {
        return jg;
    }

    public void setJg(String jg) {
        this.jg = jg;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
