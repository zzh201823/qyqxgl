package com.cwglxt.entity;

public class Food {
    private int id;
    private String name;
    private String zt;
    private String stock;
    private String jg;
    private String photo;

    public Food() {
    }

    public Food(int id, String name, String zt, String stock, String jg, String photo) {
        this.id = id;
        this.name = name;
        this.zt = zt;
        this.stock = stock;
        this.jg = jg;
        this.photo = photo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getZt() {
        return zt;
    }

    public void setZt(String zt) {
        this.zt = zt;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getJg() {
        return jg;
    }

    public void setJg(String jg) {
        this.jg = jg;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
