package com.zzh.cwglxtapp.app.VipUser;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.zzh.cwglxtapp.R;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class VipLoginActivity extends AppCompatActivity {

    private EditText umet;
    private EditText pwet;


    private Button button;
    private Button button4;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 1:
                    //获取子线程中消息传递过来的数据
                    String msgresult=msg.obj.toString();//.toString转换成字符串类型
                    if (msgresult.equals("超级用户登录成功")){
                        Toast.makeText(VipLoginActivity.this,"登入成功", Toast.LENGTH_LONG).show();
                        Intent intent=new Intent(VipLoginActivity.this, VipHomeActivity.class);
                        startActivity(intent);
                    }else {
                        Toast.makeText(VipLoginActivity.this,"登录失败", Toast.LENGTH_LONG).show();
                    }
                    break;
                case 2:
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vip_login);
        into();
    }

    private void into() {
        umet = (EditText) findViewById(R.id.umet);
        pwet = (EditText) findViewById(R.id.pwet);
        button = (Button) findViewById(R.id.button);
        button4 = (Button) findViewById(R.id.button4);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NetThread netThread = new NetThread();
                netThread.start();
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    class NetThread extends Thread{
        @Override
        public void run() {
            super.run();

            String name = umet.getText().toString();
            String pwer = pwet.getText().toString();

            try{
                String sqlString = "http://10.0.2.2:8080/servletLogin?username="+name+"&password="+pwer;
                URL url = new URL(sqlString);
                HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                //设置连接属性和参数
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                //获取响应码
                int code=connection.getResponseCode();
                if (code==200){
                    //读取输入流
                    InputStream inputStream=connection.getInputStream();
                    //将输入流对象inputStream中的数据转换成字符串
                    ByteArrayOutputStream baos=new ByteArrayOutputStream();
                    int len=0;
                    //定义一个字节数组，存放从is中读入的字节流数据
                    byte buffer[] =new byte[1024];
                    //从inputStream中最多一次读取1024字节
                    while ((len=inputStream.read(buffer))!=-1){
                        baos.write(buffer,0,len);//将buffer字节数组中的数据写入baos中
                    }
                    inputStream.close();//关闭
                    baos.close();
                    String result=new String(baos.toByteArray(),"UTF-8");
                    Message message1=handler.obtainMessage();//从消息队列中获得消息
                    //给消息编号
                    message1.what= 1 ;
                    //将子线程中的数据传递给主线程
                    message1.obj = result;
                    //将消息添加至消息队列中
                    handler.sendMessage(message1);
                }
            }catch (Exception e) {
                e.printStackTrace();
            }

        }
    }
}
