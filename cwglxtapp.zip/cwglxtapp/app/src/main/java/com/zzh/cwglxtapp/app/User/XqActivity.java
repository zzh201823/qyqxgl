package com.zzh.cwglxtapp.app.User;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.zzh.cwglxtapp.R;
import com.zzh.cwglxtapp.app.VipUser.AddFoodActivity;
import com.zzh.cwglxtapp.entity.Pet;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class XqActivity extends AppCompatActivity {

    private Pet pet;
    private ImageView photoXq;
    private TextView zltxt;
    private TextView sqtxt;
    private TextView foodtxt;
    private TextView zttxt;
    private TextView gstxt;
    private TextView jgtxt;
    private ImageButton cha,gm;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 1:
                    String result=msg.obj.toString();
                    if (result.equals("添加成功")){
                        Toast.makeText(XqActivity.this,"添加购物车成功",Toast.LENGTH_LONG).show();
                        finish();
                    }else {
                        Toast.makeText(XqActivity.this,"添加购物车失败",Toast.LENGTH_LONG).show();
                    }
                    break;
            }
        }
    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xq);
        into();
    }

    private void into() {
        photoXq = (ImageView) findViewById(R.id.photo_xq);
        zltxt = (TextView) findViewById(R.id.zltxt);
        sqtxt = (TextView) findViewById(R.id.sqtxt);
        foodtxt = (TextView) findViewById(R.id.foodtxt);
        zttxt = (TextView) findViewById(R.id.zttxt);
        gstxt = (TextView) findViewById(R.id.gstxt);
        jgtxt = (TextView) findViewById(R.id.jgtxt);
        cha = findViewById(R.id.cha);
        gm = findViewById(R.id.gouw_Ib);

        Intent intent=getIntent();
        Bundle bundle=intent.getExtras();
        pet =(Pet) bundle.getSerializable("petinf");

        String photoFile = "http://10.0.2.2:8080/upload/"+pet.getPhoto();
        Glide.with(XqActivity.this).load(photoFile).into(photoXq);

        zltxt.setText(pet.getRace());
        sqtxt.setText(pet.getJewelry());
        foodtxt.setText(pet.getFood());
        zttxt.setText(pet.getZt());
        gstxt.setText(pet.getGuas());
        jgtxt.setText(pet.getJg());

        gm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NerThread nerThread = new NerThread();
                nerThread.start();
            }
        });

        cha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    class NerThread extends Thread{
        @Override
        public void run() {
            super.run();

            String name = zltxt.getText().toString();
            String jg = jgtxt.getText().toString();

            String urlString  = "http://10.0.2.2:8080/servletGwcAdd?name="+name+"&jg="+jg+"&photo="+pet.getPhoto();

            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(3000);

                int code = connection.getResponseCode();
                if (code == 200){
                    InputStream is = connection.getInputStream();
                    ByteArrayOutputStream baos= new ByteArrayOutputStream();
                    int len = 0;
                    byte buffer[] = new byte[1024];
                    while ((len = is.read(buffer)) != -1){
                        baos.write(buffer,0,len);
                    }
                    baos.close();
                    is.close();
                    String result = new String(baos.toByteArray());
                    Message message = handler.obtainMessage();
                    message.what = 1;
                    message.obj = result;
                    handler.sendMessage(message);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
