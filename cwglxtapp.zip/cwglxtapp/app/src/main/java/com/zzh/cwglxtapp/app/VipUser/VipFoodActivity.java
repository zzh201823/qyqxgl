package com.zzh.cwglxtapp.app.VipUser;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zzh.cwglxtapp.R;
import com.zzh.cwglxtapp.app.User.FoodActivity;
import com.zzh.cwglxtapp.entity.Food;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class VipFoodActivity extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private ImageView chIv,cwIv,spIw,swIv,sousuo;
    private cwApdate cwapdate = new cwApdate();
    private List<Food> foodlist = new ArrayList();
    private int current=0;
    private int foodid;
    private ImageButton tainjai;
    private EditText editText;

    private SwipeMenuListView cwlistview;

    private Handler handler=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 1:
                    String result=msg.obj.toString();
                    //调用JsonTool工具类，将json数据转换为Java对象
                    Gson gson=new Gson();
                    foodlist=gson.fromJson(result,new TypeToken<List<Food>>(){}.getType());
                    cwlistview.setAdapter(cwapdate);
                    break;
                case 2:
                    String data=msg.obj.toString();
                    Toast.makeText(VipFoodActivity.this,data,Toast.LENGTH_LONG).show();
                    break;
                case 3:
                    String msgresult=msg.obj.toString();
                    //调用JsonTool工具类，将json数据转换为Java对象
                    gson = new Gson();
                    foodlist=gson.fromJson(msgresult,new TypeToken<List<Food>>(){}.getType());
                    cwlistview.setAdapter(cwapdate);
                    cwapdate.notifyDataSetChanged();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vip_food);
        into();
    }

    private void into() {
        drawerLayout = findViewById(R.id.drawer_layout);
        cwlistview=findViewById(R.id.cwlist);
        chIv = findViewById(R.id.cehua);
        cwIv = findViewById(R.id.cwIv);
        swIv = findViewById(R.id.swIv);
        spIw = findViewById(R.id.spIv);
        tainjai = findViewById(R.id.tainjia);
        sousuo = findViewById(R.id.sousuo);
        editText = findViewById(R.id.editText);

        sousuo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                foodlist.clear();
                String name = editText.getText().toString();
                FindNerThread findNerThread = new FindNerThread();
                findNerThread.setUrlString("http://10.0.2.2:8080/servletFindF?name="+ name);
                findNerThread.setWhat(3);
                findNerThread.start();
                cwapdate.notifyDataSetChanged();
            }
        });

        cwIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent(getApplicationContext(), VipHomeActivity.class));
                overridePendingTransition(0,0);
                finish();
            }
        });

        spIw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent(getApplicationContext(), VipJewelryActivity.class));
                overridePendingTransition(0,0);
                finish();
            }
        });

        swIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent(getApplicationContext(), VipFoodActivity.class));
                overridePendingTransition(0,0);
                finish();
            }
        });

        tainjai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VipFoodActivity.this,AddFoodActivity.class);
                startActivity(intent);
            }
        });

        FindNerThread findNerThread = new FindNerThread();
        findNerThread.setUrlString("http://10.0.2.2:8080/servletFindFood");
        findNerThread.setWhat(1);
        findNerThread.start();

        chIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VipFoodActivity.this,UserActivity.class);
                startActivity(intent);
            }
        });

        SwipeMenuCreator creator = new SwipeMenuCreator() {
            @Override
            public void create(SwipeMenu menu) {
                switch (menu.getViewType()){
                    case 0:
                        SwipeMenuItem deleteItem = new SwipeMenuItem(getApplicationContext());
                        deleteItem.setBackground(new ColorDrawable(Color.parseColor("#F40023")));//设置背景
                        deleteItem.setWidth(300);//设置滑出宽度
                        deleteItem.setTitle("删除");
                        deleteItem.setTitleColor(Color.parseColor("#ffffff"));
                        deleteItem.setTitleSize(14);
                        //deleteItem.setIcon(R.drawable.ic_delete_black_24dp);//没有删除俩字而是直接一个删除图标时.
                        // add to menu
                        menu.addMenuItem(deleteItem);
                        break;
                    case 1:

                        break;
                }
                SwipeMenuItem updateItem = new SwipeMenuItem(getApplicationContext());
                updateItem.setBackground(new ColorDrawable(Color.parseColor("#0099ff")));//设置背景
                updateItem.setWidth(300);//设置滑出宽度
                updateItem.setTitle("修改");
                updateItem.setTitleColor(Color.parseColor("#ffffff"));
                updateItem.setTitleSize(14);
                menu.addMenuItem(updateItem);
            }
        };

        cwlistview.setMenuCreator(creator);

        cwlistview.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {

                current = position;
                cwapdate.notifyDataSetChanged();

                switch (index){
                    case 0:
                        Dialog dialog=new AlertDialog.Builder(VipFoodActivity.this)
                                .setTitle("删除宠物信息")
                                .setMessage("确定删除名称为："+foodlist.get(current).getName()+"的食品吗？")
                                .setPositiveButton("是", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //访问web端删除宠物的servlet
                                        foodid=foodlist.get(current).getId();
                                        VipFoodActivity.FindNerThread findNerThread = new VipFoodActivity.FindNerThread();
                                        findNerThread.setUrlString("http://10.0.2.2:8080/servletDeleteFood?id="+foodid);
                                        findNerThread.setWhat(2);
                                        //3.获取web数据
                                        findNerThread.start();
                                        foodlist.remove(current);
                                        cwapdate.notifyDataSetChanged();
                                    }
                                })
                                .setNegativeButton("否", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                })
                                .create();
                        dialog.show();
                        break;
                    case 1:
                        Food food= foodlist.get(current);
                        Bundle bundle=new Bundle();
                        bundle.putSerializable("foodinf",food);
                        Intent intent = new Intent(VipFoodActivity.this,UpdateFoodActivity.class);
                        intent.putExtras(bundle);
                        startActivity(intent);
                        break;
                }

                return true;
            }
        });

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        foodlist.clear();
        VipFoodActivity.FindNerThread findNerThread = new VipFoodActivity.FindNerThread();
        findNerThread.setUrlString("http://10.0.2.2:8080/servletFindFood");
        findNerThread.setWhat(1);
        //3.获取web数据
        findNerThread.start();
        cwapdate.notifyDataSetChanged();
    }

    //适配器
    class cwApdate extends BaseAdapter {
        @Override
        public int getCount() {
            return foodlist.size();
        }

        @Override
        public Object getItem(int position) {
            return foodlist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            convertView=View.inflate(VipFoodActivity.this,R.layout.food_list,null);

            if (current == position){
                convertView.setBackgroundColor(Color.WHITE);
            }else {
                convertView.setBackgroundColor(Color.WHITE);
            }

            TextView pz =convertView.findViewById(R.id.zhonglei_txt);
            TextView bn =convertView.findViewById(R.id.jiage_txt);
            TextView zt = convertView.findViewById(R.id.zt_txt);
            TextView sp = convertView.findViewById(R.id.sp_txt);
            ImageView photo=convertView.findViewById(R.id.photo);

            Food food = foodlist.get(position);
            //赋值
            pz.setText(foodlist.get(position).getName());
            bn.setText(foodlist.get(position).getJg());
            zt.setText(foodlist.get(position).getZt());
            sp.setText(foodlist.get(position).getStock());
            //获取图片文件名
            String photoFile = "http://10.0.2.2:8080/upload/"+food.getPhoto();
            Glide.with(VipFoodActivity.this).load(photoFile).into(photo);
            return convertView;
        }
    }

    class FindNerThread extends Thread{
        String urlString;
        int what;

        public String getUrlString() {
            return urlString;
        }

        public void setUrlString(String urlString) {
            this.urlString = urlString;
        }

        public int getWhat() {
            return what;
        }

        public void setWhat(int what) {
            this.what = what;
        }

        @Override
        public void run() {
            super.run();
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection= (HttpURLConnection)url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                int code = connection.getResponseCode();
                if (code ==200){
                    InputStream is=connection.getInputStream();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    int len=0;
                    byte buffer[] =new byte[1024];
                    while ((len=is.read(buffer)) !=-1){
                        baos.write(buffer,0,len);
                    }
                    is.close();
                    baos.close();
                    String result = new String(baos.toByteArray(),"UTF-8");
                    Message message=handler.obtainMessage();
                    //局部变量
                    message.what=this.what;
                    message.obj=result;
                    handler.sendMessage(message);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
