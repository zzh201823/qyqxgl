package com.zzh.cwglxtapp.app.VipUser;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;


import com.zzh.cwglxtapp.R;
import com.zzh.cwglxtapp.entity.Food;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class UpdateFoodActivity extends AppCompatActivity {

    private ImageView photoXq;
    private EditText nameTxt;
    private EditText zhuangtaiTxt;
    private EditText kucunTxt;
    private EditText jgTxt;
    private ImageButton cha;
    private Button gouwIb;
    private Food food;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 1:
                    String result=msg.obj.toString();
                    if (result.equals("修改成功")){
                        Toast.makeText(UpdateFoodActivity.this,result,Toast.LENGTH_LONG).show();
                        finish();
                    }else {
                        Toast.makeText(UpdateFoodActivity.this,result,Toast.LENGTH_LONG).show();
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_jewelry);

        into();
    }

    private void into() {
        photoXq = (ImageView) findViewById(R.id.photo_xq);
        nameTxt = (EditText) findViewById(R.id.name_txt);
        zhuangtaiTxt = (EditText) findViewById(R.id.zhuangtai_txt);
        kucunTxt = (EditText) findViewById(R.id.kucun_txt);
        jgTxt = (EditText) findViewById(R.id.jg_txt);
        cha = (ImageButton) findViewById(R.id.cha);
        gouwIb = (Button) findViewById(R.id.gouw_Ib);

        final Intent intent = getIntent();
        Bundle bundle=intent.getExtras();
        food =(Food) bundle.getSerializable("foodinf");

        nameTxt.setText(food.getName());
        zhuangtaiTxt.setText(food.getZt());
        kucunTxt.setText(food.getStock());
        jgTxt.setText(food.getJg());

        gouwIb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UpdateFoodActivity.NerThread nerThread = new UpdateFoodActivity.NerThread();
                nerThread.start();
            }
        });

        cha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    class NerThread extends Thread{
        @Override
        public void run() {
            super.run();

            String name = nameTxt.getText().toString();
            String zt = zhuangtaiTxt.getText().toString();
            String kc = kucunTxt.getText().toString();
            String jg = jgTxt.getText().toString();

            String urlString  = "http://10.0.2.2:8080/servletUpdateFood?name="+name+"&zt="+zt+"&stock="+kc+"&jg="+jg+"&id="+food.getId();

            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(3000);

                int code = connection.getResponseCode();
                if (code == 200){
                    InputStream is = connection.getInputStream();
                    ByteArrayOutputStream baos= new ByteArrayOutputStream();
                    int len = 0;
                    byte buffer[] = new byte[1024];
                    while ((len = is.read(buffer)) != -1){
                        baos.write(buffer,0,len);
                    }
                    baos.close();
                    is.close();
                    String result = new String(baos.toByteArray());
                    Message message = handler.obtainMessage();
                    message.what = 1;
                    message.obj = result;
                    handler.sendMessage(message);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
