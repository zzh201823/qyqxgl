package com.zzh.cwglxtapp.entity;

public class Gwc {
    private int id;
    private String name;
    private String jg;
    private String photo;

    public Gwc() {
    }

    public Gwc(int id, String name, String jg, String photo) {
        this.id = id;
        this.name = name;
        this.jg = jg;
        this.photo = photo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJg() {
        return jg;
    }

    public void setJg(String jg) {
        this.jg = jg;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}
