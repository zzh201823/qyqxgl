package com.zzh.cwglxtapp.tool;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zzh.cwglxtapp.entity.User;

import java.util.ArrayList;
import java.util.List;

public class JsonTool {
    public static List<User> getUserList(String jsonString) {
        List<User> list = new ArrayList<>();
        Gson gson = new Gson();
        //讲gson数据转换成Java对象
        list = gson.fromJson(jsonString, new TypeToken<List<User>>() {}.getType());
        return list;
    }
}
