package com.zzh.cwglxtapp.app.User;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zzh.cwglxtapp.R;
import com.zzh.cwglxtapp.entity.Pet;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ImageView chIv,cwIv,spIw,swIv,sousuo;
    private cwApdate cwapdate = new cwApdate();
    private List<Pet> petlist = new ArrayList();
    private int current=0;
    private EditText editText;
    private ListView cwlistview;

    private Handler handler=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 1:
                    String result=msg.obj.toString();
                    //调用JsonTool工具类，将json数据转换为Java对象
                    Gson gson=new Gson();
                    petlist=gson.fromJson(result,new TypeToken<List<Pet>>(){}.getType());
                    cwlistview.setAdapter(cwapdate);
                    break;
                case 2:
                    String msgresult=msg.obj.toString();
                    //调用JsonTool工具类，将json数据转换为Java对象
                    gson = new Gson();
                    petlist=gson.fromJson(msgresult,new TypeToken<List<Pet>>(){}.getType());
                    cwlistview.setAdapter(cwapdate);
                    cwapdate.notifyDataSetChanged();
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        into();
    }

    private void into() {
        drawerLayout = findViewById(R.id.drawer_layout);
        cwlistview=findViewById(R.id.cwlist);
        chIv = findViewById(R.id.cehua);
        cwIv = findViewById(R.id.cwIv);
        swIv = findViewById(R.id.swIv);
        spIw = findViewById(R.id.spIv);
        sousuo = findViewById(R.id.sousuo);
        editText = findViewById(R.id.editText);

        final FindNerThread findNerThread = new FindNerThread();
        findNerThread.setUrlString("http://10.0.2.2:8080/servletFindPet");
        findNerThread.setWhat(1);
        findNerThread.start();

        cwlistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //点击变色
                current = position;
                cwapdate.notifyDataSetChanged();

                Pet pet=petlist.get(current);
                Bundle bundle=new Bundle();
                bundle.putSerializable("petinf",pet);
                Intent intent = new Intent(HomeActivity.this, XqActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        sousuo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                petlist.clear();
                String race = editText.getText().toString();
                FindNerThread findNerThread = new FindNerThread();
                findNerThread.setUrlString("http://10.0.2.2:8080/servletFind?race="+race);
                findNerThread.setWhat(2);
                findNerThread.start();
                cwapdate.notifyDataSetChanged();
            }
        });

        chIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        cwIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent(getApplicationContext(), HomeActivity.class));
                overridePendingTransition(0,0);
                finish();
            }
        });

        spIw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(HomeActivity.this,JewelryActivity.class);
//                startActivity(intent);
                startActivity( new Intent(getApplicationContext(), JewelryActivity.class));
                overridePendingTransition(0,0);
                finish();
            }
        });

        swIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(HomeActivity.this, FoodActivity.class);
//                startActivity(intent);
                startActivity( new Intent(getApplicationContext(), FoodActivity.class));
                overridePendingTransition(0,0);
                finish();
            }
        });

        drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {

            }

            @Override
            public void onDrawerOpened(@NonNull View drawerView) {
                findViewById(R.id.item_update).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeActivity.this, UserUpdateActivity.class);
                        startActivity(intent);
                    }
                });
                findViewById(R.id.item_gwc).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeActivity.this,GwcActivity.class);
                        startActivity(intent);
                    }
                });
                findViewById(R.id.item_help).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(HomeActivity.this,HelpActivity.class);
                        startActivity(intent);
                    }
                });
            }

            @Override
            public void onDrawerClosed(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        petlist.clear();
        FindNerThread findNerThread = new FindNerThread();
        findNerThread.setUrlString("http://10.0.2.2:8080/servletFindPet");
        findNerThread.setWhat(1);
        //3.获取web数据
        findNerThread.start();
        cwapdate.notifyDataSetChanged();
    }

    //适配器
    class cwApdate extends BaseAdapter{
        @Override
        public int getCount() {
            return petlist.size();
        }

        @Override
        public Object getItem(int position) {
            return petlist.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView=View.inflate(HomeActivity.this,R.layout.cw_list,null);

            if (current == position){

            }else {
                convertView.setBackgroundColor(Color.WHITE);
            }
            TextView pz=convertView.findViewById(R.id.zhonglei_txt);
            TextView bn=convertView.findViewById(R.id.jiage_txt);
            TextView zt = convertView.findViewById(R.id.zt_txt);
            TextView sp = convertView.findViewById(R.id.sp_txt);
            ImageView photo=convertView.findViewById(R.id.photo);

            Pet pet = petlist.get(position);
            //赋值
            pz.setText(petlist.get(position).getRace());
            bn.setText(petlist.get(position).getJg());
            zt.setText(petlist.get(position).getZt());
            sp.setText(petlist.get(position).getJewelry());
            //获取图片文件名
            String photoFile = "http://10.0.2.2:8080/upload/"+pet.getPhoto();
            Glide.with(HomeActivity.this).load(photoFile).into(photo);
            return convertView;
        }
    }

    class FindNerThread extends Thread{
        String urlString;
        int what;

        public String getUrlString() {
            return urlString;
        }

        public void setUrlString(String urlString) {
            this.urlString = urlString;
        }

        public int getWhat() {
            return what;
        }

        public void setWhat(int what) {
            this.what = what;
        }

        @Override
        public void run() {
            super.run();
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection= (HttpURLConnection)url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                int code = connection.getResponseCode();
                if (code ==200){
                    InputStream is=connection.getInputStream();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    int len=0;
                    byte buffer[] =new byte[1024];
                    while ((len=is.read(buffer)) !=-1){
                        baos.write(buffer,0,len);
                    }
                    is.close();
                    baos.close();
                    String result = new String(baos.toByteArray(),"UTF-8");
                    Message message=handler.obtainMessage();
                    //局部变量
                    message.what=this.what;
                    message.obj=result;
                    handler.sendMessage(message);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
