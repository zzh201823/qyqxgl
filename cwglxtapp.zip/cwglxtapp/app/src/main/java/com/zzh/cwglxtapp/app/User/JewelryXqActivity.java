package com.zzh.cwglxtapp.app.User;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.zzh.cwglxtapp.R;
import com.zzh.cwglxtapp.entity.Jewelry;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class JewelryXqActivity extends AppCompatActivity {
    private Jewelry jewelry;
    private ImageView photoXq;
    private TextView zltxt;
    private TextView sqtxt;
    private TextView jewelrytxt;
    private TextView zttxt;
    private ImageButton cha,gm;
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 1:
                    String result=msg.obj.toString();
                    if (result.equals("添加成功")){
                        Toast.makeText(JewelryXqActivity.this,"添加购物车成功",Toast.LENGTH_LONG).show();
                        finish();
                    }else {
                        Toast.makeText(JewelryXqActivity.this,"添加购物车失败",Toast.LENGTH_LONG).show();
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jewelry_xq);
        
        into();
    }

    private void into() {
        photoXq = (ImageView) findViewById(R.id.photo_xq);
        zltxt = (TextView) findViewById(R.id.zltxt);
        sqtxt = (TextView) findViewById(R.id.sqtxt);
        jewelrytxt = (TextView) findViewById(R.id.foodtxt);
        zttxt = (TextView) findViewById(R.id.zttxt);

        cha = findViewById(R.id.cha);
        gm = findViewById(R.id.gouw_Ib);

        Intent intent=getIntent();
        Bundle bundle=intent.getExtras();
        jewelry =(Jewelry) bundle.getSerializable("jewelryinf");

        String photoFile = "http://10.0.2.2:8080/upload/"+jewelry.getPhoto();
        Glide.with(JewelryXqActivity.this).load(photoFile).into(photoXq);

        zltxt.setText(jewelry.getName());
        sqtxt.setText(jewelry.getZt());
        jewelrytxt.setText(jewelry.getStock());
        zttxt.setText(jewelry.getJg());


        gm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JewelryXqActivity.NerThread nerThread = new JewelryXqActivity.NerThread();
                nerThread.start();
            }
        });

        cha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    class NerThread extends Thread{
        @Override
        public void run() {
            super.run();

            String name = zltxt.getText().toString();
            String jg = zttxt.getText().toString();

            String urlString  = "http://10.0.2.2:8080/servletGwcAdd?name="+name+"&jg="+jg+"&photo="+jewelry.getPhoto();

            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(3000);

                int code = connection.getResponseCode();
                if (code == 200){
                    InputStream is = connection.getInputStream();
                    ByteArrayOutputStream baos= new ByteArrayOutputStream();
                    int len = 0;
                    byte buffer[] = new byte[1024];
                    while ((len = is.read(buffer)) != -1){
                        baos.write(buffer,0,len);
                    }
                    baos.close();
                    is.close();
                    String result = new String(baos.toByteArray());
                    Message message = handler.obtainMessage();
                    message.what = 1;
                    message.obj = result;
                    handler.sendMessage(message);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
