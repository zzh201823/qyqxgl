package com.zzh.cwglxtapp.app.VipUser;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.zzh.cwglxtapp.R;
import com.zzh.cwglxtapp.entity.Pet;
import com.zzh.cwglxtapp.entity.User;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class UpdateUserActivity extends AppCompatActivity {

    private EditText nameTxt;
    private EditText zhuangtaiTxt;
    private ImageView cha;
    private Button gouwIb;
    private User user;


    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 1:
                    String result=msg.obj.toString();
                    if (result.equals("修改成功")){
                        Toast.makeText(UpdateUserActivity.this,result,Toast.LENGTH_LONG).show();
                        finish();
                    }else {
                        Toast.makeText(UpdateUserActivity.this,result,Toast.LENGTH_LONG).show();
                    }
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_user);

        into();
    }

    private void into() {
        nameTxt = (EditText) findViewById(R.id.name_txt);
        zhuangtaiTxt = (EditText) findViewById(R.id.zhuangtai_txt);
        cha = findViewById(R.id.cha);
        gouwIb = (Button) findViewById(R.id.gouw_Ib);

        cha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        final Intent intent = getIntent();
        Bundle bundle=intent.getExtras();
        user =(User) bundle.getSerializable("userinf");

        nameTxt.setText(user.getUsername());
        zhuangtaiTxt.setText(user.getPassword());

        gouwIb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NerThread nerThread = new NerThread();
                nerThread.start();
            }
        });

        cha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    class NerThread extends Thread{
        @Override
        public void run() {
            super.run();

            String username = nameTxt.getText().toString();
            String password = zhuangtaiTxt.getText().toString();

            String urlString  = "http://10.0.2.2:8080/servletUserUpdate?username="+username+"&password="+password+"&id="+user.getId();
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(3000);

                int code = connection.getResponseCode();
                if (code == 200){
                    InputStream is = connection.getInputStream();
                    ByteArrayOutputStream baos= new ByteArrayOutputStream();
                    int len = 0;
                    byte buffer[] = new byte[1024];
                    while ((len = is.read(buffer)) != -1){
                        baos.write(buffer,0,len);
                    }
                    baos.close();
                    is.close();
                    String result = new String(baos.toByteArray());
                    Message message = handler.obtainMessage();
                    message.what = 1;
                    message.obj = result;
                    handler.sendMessage(message);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
